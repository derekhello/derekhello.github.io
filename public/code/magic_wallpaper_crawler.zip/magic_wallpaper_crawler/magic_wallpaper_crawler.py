import os
import requests
from bs4 import BeautifulSoup


search_query = "Chinese_New_Year_2025"
URL = f'https://bing.wdbyte.com/?q={search_query}'
head = {'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}

response = requests.get(URL,headers=head)
res = BeautifulSoup(response.text,'html.parser')

folder_name = 'bing_images'
if not os.path.exists(folder_name):
    os.makedirs(folder_name)

img_div = res.find_all('div',class_='w3-third')
img_url_list = []
data_list = []

for i in img_div:
    data = i.p.text[0:11]
    href = i.p.a['href']
    img_url_list.append(href)
    data_list.append(data)

j = 0
for i in img_url_list:
    response = requests.get(i,headers=head) 
    with open(f'{folder_name}/{data_list[j]}.jpg','wb') as f:
        f.write(response.content)
    j += 1

print("Images downloaded and saved to folder:", folder_name)