# 人脸识别表情
import cv2

# 初始化摄像头
cap = cv2.VideoCapture(0)

# 加载分类器
face_cascade = cv2.CascadeClassifier(
    "haarcascade_frontalface_default.xml")
smile_cascade = cv2.CascadeClassifier(
    "haarcascade_smile.xml")

# 加载表情图片并调整大小
img_happy = cv2.resize(cv2.imread("happy.png"), (100, 100))
img_sad = cv2.resize(cv2.imread("sad.png"), (100, 100))

# 表情图片显示位置
emotion_pos = (20, 20)  # 左上角坐标

while True:
    ret, frame = cap.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)

    current_emotion = None

    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
        roi_gray = gray[y:y + h, x:x + w]
        roi_color = frame[y:y + h, x:x + w]

        # 检测笑容
        smiles = smile_cascade.detectMultiScale(
            roi_gray,
            scaleFactor=1.4,
            minNeighbors=35,
            minSize=(25, 25)
        )

        # 判断表情
        if len(smiles) >= 1:
            current_emotion = img_happy
            cv2.putText(frame, 'HAPPY', (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        else:
            current_emotion = img_sad
            cv2.putText(frame, 'SAD', (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

    # 在画面左上角显示表情图标
    if current_emotion is not None:
        x, y = emotion_pos
        frame[y:y + 100, x:x + 100] = current_emotion

    # 显示合并后的画面
    cv2.imshow('Emotion Detection', frame)

    if cv2.waitKey(1) == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()