import pygame
from pygame.locals import *
from sys import exit
import random


def main():
    bird = [pygame.image.load("image/0.png"),
            pygame.image.load("image/1.png"),
            pygame.image.load("image/2.png"),
            pygame.image.load("image/dead.png")]
    background = pygame.image.load("image/background.png")
    pipe_up = pygame.image.load("image/top.png")
    pipe_down = pygame.image.load("image/bottom.png")

    pygame.init()
    pygame.mixer.init()
    pygame.mixer.music.load("sound/jumping_sound.wav")
    pygame.mixer.music.set_volume(0.1)

    font = pygame.font.SysFont("Arial", 50)
    text = font.render("GAME OVER", True, (255,255,255))

    screen = pygame.display.set_mode((400,700))
    pygame.display.set_caption("flappy bird")
    clock = pygame.time.Clock()
    random_y = (random.randint(-10,10))*20
    i = 0
    pipe_x = 400
    birdy = 350
    bird_speed = 0
    gravity = 0.3
    score = 0

    s_text = font.render(f"SCORE:{score}", True, (255,255,0))
    bird_live = True
    while True:
        if bird_live:
            screen.blit(background, (0, 0))
            screen.blit(bird[i%3], (80,birdy))
            screen.blit(pipe_up, (pipe_x,-225+random_y))
            screen.blit(pipe_down, (pipe_x, 425+random_y))
            screen.blit(s_text, (100, 50))
            if pipe_x < -100:
                score += 1
                s_text = font.render(f"SCORE:{score}", True, (255,255,0))
                pipe_x = 400
                random_y = (random.randint(-7,7))*30
            pipe_x -= 2
            bird_speed += gravity
            birdy += bird_speed

            if birdy>670 or birdy < 0:
                screen.blit(text, (75, 350))
                print("GAME OVER")
                bird_live = False
            if -18 < pipe_x < 120:
                if birdy < -225+random_y+495 or birdy > 425+random_y:
                    screen.blit(text, (75, 350))
                    print("GAME OVER")
                    bird_live = False
        
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    exit()
                if event.type == KEYDOWN:
                    if event.key == K_SPACE:
                        pygame.mixer.music.play()
                        bird_speed = -5
            pygame.display.update()
            clock.tick(60)
            i += 1
        else:
            if birdy<750:
                screen.blit(background, (0, 0))
                screen.blit(pipe_up, (pipe_x,-225+random_y))
                screen.blit(pipe_down, (pipe_x, 425+random_y))
                screen.blit(s_text, (100, 50))
                screen.blit(text, (75, 350))
                screen.blit(bird[3], (80,birdy))
                birdy += bird_speed
                bird_speed += gravity
                pygame.display.update()
                clock.tick(60)
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    exit()
                if event.type == KEYDOWN:
                    if event.key == K_RETURN:
                        bird_live = True
                        score = 0
                        birdy = 350
                        bird_speed = 0
                        pipe_x =400

if __name__ == '__main__':
    main()
