import pygame
from pygame.locals import *
from sys import exit
import random


def main():
    
    # 游戏资源的准备
    bird = [pygame.image.load("image/0.png"),
            pygame.image.load("image/1.png"),
            pygame.image.load("image/2.png"),
            pygame.image.load("image/dead.png")]
    background = pygame.image.load("image/background.png")
    pipe_up = pygame.image.load("image/top.png")
    pipe_down = pygame.image.load("image/bottom.png")

    pygame.init()
    pygame.mixer.init()
    pygame.mixer.music.load("sound/跳跃音效.wav")
    pygame.mixer.music.set_volume(0.1)
    # 1、创建字体对象
    font = pygame.font.SysFont("Arial", 50)
    # 2、通过字体对象创建字体内容以及一些字体的属性
    text = font.render("GAME OVER", True, (255,255,255))
    # 3、把字体内容绘制到屏幕上
    screen = pygame.display.set_mode((400,700))
    pygame.display.set_caption("flappy bird")
    clock = pygame.time.Clock()
    random_y = (random.randint(-10,10))*20
    i = 0
    pipe_x = 400
    birdy = 350
    bird_speed = 0
    gravity = 0.3
    score = 0
    # 采用f-string 方式来给分值进行占位
    s_text = font.render(f"SCORE:{score}", True, (255,255,0))
    bird_live = True
    while True:
        if bird_live:
            screen.blit(background, (0, 0))
            screen.blit(bird[i%3], (80,birdy))
            screen.blit(pipe_up, (pipe_x,-225+random_y))
            screen.blit(pipe_down, (pipe_x, 425+random_y))
            screen.blit(s_text, (100, 50))
            if pipe_x < -100:
                # print('-----------------------------------')
                score += 1
                s_text = font.render(f"SCORE:{score}", True, (255,255,0))
                pipe_x = 400
                random_y = (random.randint(-7,7))*30
                # random_y    如何取值？  rbackground, (0, 0)andint（-100,100） 
            pipe_x -= 2
            bird_speed += gravity
            birdy += bird_speed

            if birdy>670 or birdy < 0:
                screen.blit(text, (75, 350))
                print("GAME OVER")
                bird_live = False
            if pipe_x<120 and pipe_x > -18:
                if birdy < -225+random_y+495 or birdy > 425+random_y:
                    screen.blit(text, (75, 350))
                    print("GAME OVER")
                    bird_live = False
        
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    exit()
                if event.type == KEYDOWN:
                    if event.key == K_SPACE:
                        pygame.mixer.music.play()
                        bird_speed = -5
            pygame.display.update()
            clock.tick(60)
            i += 1
        else:
            # 写一个小鸟坠落的动画
            if birdy<750:
                screen.blit(background, (0, 0))
                screen.blit(pipe_up, (pipe_x,-225+random_y))
                screen.blit(pipe_down, (pipe_x, 425+random_y))
                screen.blit(s_text, (100, 50))
                screen.blit(text, (75, 350))
                screen.blit(bird[3], (80,birdy))
                birdy += bird_speed
                bird_speed += gravity
                pygame.display.update()
                clock.tick(60)
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    exit()
                if event.type == KEYDOWN:
                    if event.key == K_RETURN:
                        bird_live = True
                        score = 0
                        birdy = 350
                        bird_speed = 0
                        pipe_x =400

if __name__ == '__main__':
    main()

# 打包命令,先进入打包文件夹，然后执行打包命令
# cd /Users/quentin/Desktop/flappy_bird
# pyinstaller -F --add-data="image:image" main.py  
# -F 打包成一个exe文件
# -W 没有终端后台界面
# 注意点:把image文件夹放在打包好的dist文件夹内,运行的时候才能找到

# 自由拓展