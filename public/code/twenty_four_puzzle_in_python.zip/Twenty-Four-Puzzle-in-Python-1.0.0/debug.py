# None
import algorithm

answer = [1, '-', 1,  '*', '(', 1, '-', 24, ')']
print(algorithm.simplify_formula_first_part(answer))

