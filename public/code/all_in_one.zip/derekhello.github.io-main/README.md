# derekhello.github.io

# Start

## Node version

```
v20.16.0 +
```

## Install Dependencies

```
yarn
```

## Dev

```
yarn dev
```

## Build

```
yarn build
```
