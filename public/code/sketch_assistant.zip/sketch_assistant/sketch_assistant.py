from PIL import Image, ImageFilter, ImageOps
import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox

def apply_effect(image, effect):
    """choose different applications based on user decisions"""
    if effect == "sketch":
        gray_img = image.convert('L')
        sketch_img = gray_img.filter(ImageFilter.FIND_EDGES)
        sketch_img = ImageOps.invert(sketch_img)
        return sketch_img
    elif effect == "negative":
        inverted_img = ImageOps.invert(image.convert("RGB"))
        return inverted_img
    else:
        return image

def open_image():
    """open image file"""
    file_path = filedialog.askopenfilename(
        title="choose an image",
        initialdir='./',
        filetypes=[("Images", "*.jpg *.jpeg *.png")]
    )
    if file_path:
        img = Image.open(file_path)
        return img
    return None

def show_image(image):
    """show image"""
    image.show()

def on_apply_effect():
    """apply effect to image"""
    effect = effect_var.get()
    img = open_image()
    if img:
        processed_img = apply_effect(img, effect)
        show_image(processed_img)
    else:
        messagebox.showerror("Error", "No image selected")

root = tk.Tk()
root.title("Sketch Assistant")
root.geometry("300x130")

effect_var = tk.StringVar(root)
effect_var.set("sketch")
effects = ["sketch",  "negative"]
effect_menu = tk.OptionMenu(root, effect_var, *effects)
effect_menu.pack(pady=20)

apply_button = tk.Button(root, text="choose image application", command=on_apply_effect)
apply_button.pack(pady=10)

root.mainloop()